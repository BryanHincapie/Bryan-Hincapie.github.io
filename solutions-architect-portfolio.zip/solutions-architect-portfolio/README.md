# Portfolio — Solutions Architect | Data, Cloud & AI

Sitio profesional estático en español, listo para publicar con GitHub Pages. No requiere frameworks, backend ni dependencias para funcionar.

## Antes de publicarlo

1. Abrí `index.html` y buscá `TU_EMAIL@EJEMPLO.COM`; reemplazalo por tu email profesional.
2. Buscá `https://www.linkedin.com/` y reemplazalo por la URL de tu perfil.
3. Revisá las capacidades y eliminá cualquier servicio que no quieras ofrecer o que no represente tu experiencia.
4. No publiques diagramas, datos, nombres ni métricas confidenciales de clientes.

## Publicar gratis en GitHub Pages

1. En GitHub, creá un repositorio público llamado exactamente `TU-USUARIO.github.io` (reemplazá `TU-USUARIO` por tu usuario real de GitHub).
2. Subí todos los archivos de esta carpeta a la raíz del repositorio, incluido `index.html` y `.nojekyll`.
3. Entrá en **Settings → Pages**.
4. En **Build and deployment**, elegí **Deploy from a branch**, seleccioná `main` y `/ (root)`, y guardá.
5. Esperá la publicación y abrí `https://TU-USUARIO.github.io`.

GitHub Pages permite alojar sitios estáticos en GitHub Free desde repositorios públicos. La URL `github.io` no tiene costo; un dominio personalizado es opcional y normalmente se compra por separado.

## Personalización visual

- Colores principales: carbón `#111315`, amarillo `#f4c928`, blanco cálido y grises.
- Estilos: `styles.css`.
- Menú móvil y año del footer: `script.js`.
- Todo el contenido principal: `index.html`.

La fuente se carga desde Google Fonts; si no está disponible, se usan fuentes de respaldo del sistema.
